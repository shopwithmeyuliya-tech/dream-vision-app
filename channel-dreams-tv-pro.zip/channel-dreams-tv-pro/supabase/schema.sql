-- Run once in Supabase SQL Editor. Public profiles/posts; private dreams and messages.
create extension if not exists pgcrypto;
create table if not exists public.profiles (
 id uuid primary key references auth.users(id) on delete cascade,
 username text unique not null check (username ~ '^[a-z0-9_]{3,24}$'),
 display_name text not null default 'Мечтатель', bio text not null default '',
 created_at timestamptz not null default now()
);
create table if not exists public.dreams (
 id uuid primary key default gen_random_uuid(), user_id uuid not null references auth.users(id) on delete cascade,
 title text not null check (char_length(title) between 1 and 150), body text not null check (char_length(body) between 1 and 15000),
 dream_date date not null default current_date, mood text not null default 'Загадочный', symbols text[] not null default '{}',
 created_at timestamptz not null default now()
);
create table if not exists public.posts (
 id uuid primary key default gen_random_uuid(), user_id uuid not null references auth.users(id) on delete cascade,
 dream_id uuid references public.dreams(id) on delete set null,
 caption text not null check (char_length(caption) between 1 and 5000),
 created_at timestamptz not null default now()
);
create table if not exists public.follows (
 follower_id uuid not null references auth.users(id) on delete cascade,
 following_id uuid not null references auth.users(id) on delete cascade,
 created_at timestamptz not null default now(), primary key(follower_id,following_id),
 check (follower_id <> following_id)
);
create table if not exists public.likes (
 user_id uuid not null references auth.users(id) on delete cascade,
 post_id uuid not null references public.posts(id) on delete cascade,
 created_at timestamptz not null default now(), primary key(user_id,post_id)
);
create table if not exists public.comments (
 id uuid primary key default gen_random_uuid(), user_id uuid not null references auth.users(id) on delete cascade,
 post_id uuid not null references public.posts(id) on delete cascade,
 body text not null check (char_length(body) between 1 and 1000),
 created_at timestamptz not null default now()
);
create table if not exists public.messages (
 id uuid primary key default gen_random_uuid(), sender_id uuid not null references auth.users(id) on delete cascade,
 recipient_id uuid not null references auth.users(id) on delete cascade,
 body text not null check (char_length(body) between 1 and 2000),
 created_at timestamptz not null default now(), check (sender_id <> recipient_id)
);
create index if not exists posts_created_idx on public.posts(created_at desc);
create index if not exists messages_pair_idx on public.messages(sender_id,recipient_id,created_at);
create index if not exists dreams_user_idx on public.dreams(user_id,dream_date desc);
create index if not exists comments_post_idx on public.comments(post_id,created_at);
create or replace function public.create_profile() returns trigger language plpgsql security definer set search_path = '' as $$
begin
 insert into public.profiles(id,username,display_name) values (
 new.id, 'dreamer_' || substr(replace(new.id::text,'-',''),1,16),
 coalesce(nullif(left(new.raw_user_meta_data->>'display_name',60),''),'Мечтатель'));
 return new;
end; $$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users for each row execute function public.create_profile();
-- Handle accounts created before schema installation
insert into public.profiles(id,username,display_name)
select id,'dreamer_' || substr(replace(id::text,'-',''),1,16),'Мечтатель' from auth.users
on conflict (id) do nothing;
alter table public.profiles enable row level security;
alter table public.dreams enable row level security;
alter table public.posts enable row level security;
alter table public.follows enable row level security;
alter table public.likes enable row level security;
alter table public.comments enable row level security;
alter table public.messages enable row level security;
create policy "profiles readable" on public.profiles for select to authenticated using (true);
create policy "profiles self update" on public.profiles for update to authenticated using (id=auth.uid()) with check (id=auth.uid());
create policy "dreams owner read" on public.dreams for select to authenticated using (user_id=auth.uid());
create policy "dreams owner insert" on public.dreams for insert to authenticated with check (user_id=auth.uid());
create policy "dreams owner update" on public.dreams for update to authenticated using (user_id=auth.uid()) with check (user_id=auth.uid());
create policy "dreams owner delete" on public.dreams for delete to authenticated using (user_id=auth.uid());
create policy "posts read" on public.posts for select to authenticated using (true);
create policy "posts self insert" on public.posts for insert to authenticated with check (user_id=auth.uid() and (dream_id is null or exists(select 1 from public.dreams d where d.id=dream_id and d.user_id=auth.uid())));
create policy "posts self update" on public.posts for update to authenticated using (user_id=auth.uid()) with check (user_id=auth.uid() and (dream_id is null or exists(select 1 from public.dreams d where d.id=dream_id and d.user_id=auth.uid())));
create policy "posts self delete" on public.posts for delete to authenticated using (user_id=auth.uid());
create policy "follows read" on public.follows for select to authenticated using (true);
create policy "follows self insert" on public.follows for insert to authenticated with check (follower_id=auth.uid());
create policy "follows self delete" on public.follows for delete to authenticated using (follower_id=auth.uid());
create policy "likes read" on public.likes for select to authenticated using (true);
create policy "likes self insert" on public.likes for insert to authenticated with check (user_id=auth.uid());
create policy "likes self delete" on public.likes for delete to authenticated using (user_id=auth.uid());
create policy "comments read" on public.comments for select to authenticated using (true);
create policy "comments self insert" on public.comments for insert to authenticated with check (user_id=auth.uid());
create policy "comments self delete" on public.comments for delete to authenticated using (user_id=auth.uid());
create policy "messages participants read" on public.messages for select to authenticated using (sender_id=auth.uid() or recipient_id=auth.uid());
create policy "messages sender insert" on public.messages for insert to authenticated with check (sender_id=auth.uid());
create policy "messages sender delete" on public.messages for delete to authenticated using (sender_id=auth.uid());
