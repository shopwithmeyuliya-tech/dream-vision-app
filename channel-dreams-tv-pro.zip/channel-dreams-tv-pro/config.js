window.DREAMS_CONFIG = {
  supabaseUrl: '', // https://YOUR_PROJECT.supabase.co
  supabaseAnonKey: '' // public publishable/anon key; NEVER service_role key
};
